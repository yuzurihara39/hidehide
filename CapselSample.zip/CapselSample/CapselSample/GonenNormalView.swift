//
//  GonenNormalView.swift
//  CapselSample
//
//  Created by cmStudent on 2022/11/30.
//

import SwiftUI

struct GonenNormalView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct GonenNormalView_Previews: PreviewProvider {
    static var previews: some View {
        GonenNormalView()
    }
}

//
//  Dog.swift
//  CapselSample
//
//  Created by cmStudent on 2023/02/08.
//

import Foundation
import SwiftUI

struct Dog: Hashable
{
   
    var breed: String
    var score: String

    
}

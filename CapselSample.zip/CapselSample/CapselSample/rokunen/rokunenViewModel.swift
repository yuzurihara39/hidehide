//
//  rokunenViewModel.swift
//  CapselSample
//
//  Created by cmStudent on 2023/02/13.
//

import Foundation
class rokunenViewMOdel : ObservableObject{
    @Published var SixEasyshowingModal = false
    @Published var SixNormalshowingModa2 = false
    @Published var SixHardshowingModa3 = false
}

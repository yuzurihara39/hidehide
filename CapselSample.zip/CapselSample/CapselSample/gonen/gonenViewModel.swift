//
//  gonenViewModel.swift
//  CapselSample
//
//  Created by cmStudent on 2023/02/13.
//

import Foundation
class gonenViewMOdel : ObservableObject{
    @Published var showingModal = false
    @Published var showingModa2 = false
    @Published var showingModa3 = false
}
